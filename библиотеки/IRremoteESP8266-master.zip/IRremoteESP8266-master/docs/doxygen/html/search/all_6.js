var searchData=
[
  ['fahrenheittocelsius_257',['fahrenheitToCelsius',['../IRutils_8cpp.html#a83538e86145850c24b1c824723089502',1,'fahrenheitToCelsius(const float deg):&#160;IRutils.cpp'],['../IRutils_8h.html#a83538e86145850c24b1c824723089502',1,'fahrenheitToCelsius(const float deg):&#160;IRutils.cpp']]],
  ['fanspeed_258',['fanspeed',['../structstdAc_1_1state__t.html#a28a50c877a0eaa71689ccc3bf9c957d7',1,'stdAc::state_t']]],
  ['fanspeed_5ft_259',['fanspeed_t',['../namespacestdAc.html#a8bb0dbf18fe69f639f4ac0b3ff133383',1,'stdAc']]],
  ['fanspeedtostring_260',['fanspeedToString',['../classIRac.html#ab8d8a1ce5de8970c07c90fb41731e2e6',1,'IRac']]],
  ['filter_261',['filter',['../structstdAc_1_1state__t.html#a41e4b957f9e011ddb32d35bfcd56c0e7',1,'stdAc::state_t']]],
  ['fixchecksum_262',['fixChecksum',['../classIRPanasonicAc.html#aa40bef35000ddf6d14e286b3f2044897',1,'IRPanasonicAc']]],
  ['fixup_263',['fixup',['../classIRGreeAC.html#a5bbdcc83f9d49e32379cd27cad0ba130',1,'IRGreeAC::fixup()'],['../classIRKelvinatorAC.html#a389af589003c39794ae5d4bd572fa485',1,'IRKelvinatorAC::fixup()']]],
  ['flap_5fmode_264',['flap_mode',['../classIRArgoAC.html#abfc383d92ced7d47945cc5ac996e5fc4',1,'IRArgoAC']]],
  ['fr_2dfr_2eh_265',['fr-FR.h',['../fr-FR_8h.html',1,'']]],
  ['fujitsu_266',['fujitsu',['../classIRac.html#a23cf80270562ca28ae1f1da2bbb559e7',1,'IRac']]],
  ['fujitsu_5fac_267',['FUJITSU_AC',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadad8cf99a3a8776d644b78313306a2108c',1,'IRremoteESP8266.h']]],
  ['fujitsu_5fac_5fremote_5fmodel_5ft_268',['fujitsu_ac_remote_model_t',['../IRsend_8h.html#a7204e78a1fe37a819c0b66f87a685dc0',1,'IRsend.h']]]
];
