var searchData=
[
  ['carrier_5fac_6997',['CARRIER_AC',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada4d7328071e0a48bc828fccb02f969c20',1,'IRremoteESP8266.h']]],
  ['carrier_5fac40_6998',['CARRIER_AC40',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada1340c578f7986b0ed126744127af3907',1,'IRremoteESP8266.h']]],
  ['carrier_5fac64_6999',['CARRIER_AC64',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada4122973f5d8ce282457d348857ba0af0',1,'IRremoteESP8266.h']]],
  ['coolix_7000',['COOLIX',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadae561d1d82d90c1b54a1a502431749873',1,'IRremoteESP8266.h']]],
  ['corona_5fac_7001',['CORONA_AC',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadaf61f2c360f487309cfa466a44fcae106',1,'IRremoteESP8266.h']]]
];
