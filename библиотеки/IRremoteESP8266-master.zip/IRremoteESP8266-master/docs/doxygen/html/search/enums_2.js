var searchData=
[
  ['gree_5fac_5fremote_5fmodel_5ft_6979',['gree_ac_remote_model_t',['../IRsend_8h.html#af65070c92b97fa00b2de3818c46039c9',1,'IRsend.h']]]
];
